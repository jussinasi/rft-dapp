# RFT Coin dApp (Vite + React)

Vite-versio React dAppista Solana-ympäristöön.